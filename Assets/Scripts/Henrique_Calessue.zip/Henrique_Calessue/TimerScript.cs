using TMPro;
using UnityEngine;

public class TimerScript : MonoBehaviour
{
    public TMP_Text timerText;
    private float currentTimer;
    private bool isCounting = true;

    private static TimerScript instance;

    void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject); // Mant�m o objeto vivo entre cenas
        }
        else
        {
            Destroy(gameObject); // Garante que s� um Timer exista
        }
    }

    void Update()
    {
        if (!isCounting) return;

        currentTimer += Time.deltaTime;
        float seconds = Mathf.FloorToInt(currentTimer % 60);
        if (timerText != null)
            timerText.text = $"{seconds:00}";
    }

    public int GetTimerAndStop()
    {
        isCounting = false;
        return (int)currentTimer;
    }

    public void ResumeTimer()
    {
        isCounting = true;
    }

    public void SetTimerText(TMP_Text newText)
    {
        timerText = newText; // �til ao carregar nova cena
    }
}

